/*
 * sensor.c
 *
 *  Created on: Aug 7, 2024
 *      Author: guidomomm
 */


#include "sensor.h"

//extern TIM_HandleTypeDef htim1;

void sensor_config(sensor_t *sr04, uint16_t trig_pin, GPIO_TypeDef *trig_port, uint16_t echo_channel, TIM_HandleTypeDef *echo_htim)
{
  sr04->trig_port = trig_port;
  sr04->trig_pin = trig_pin;
  sr04->echo_htim = echo_htim;
  sr04->echo_channel = echo_channel;
}

/*
void sensor_init(sensor_t *sr04)
{

  HAL_GPIO_WritePin(sr04->trig_port, sr04->trig_pin, GPIO_PIN_RESET);

  __HAL_TIM_SET_CAPTUREPOLARITY(sr04->echo_htim, sr04->echo_channel, TIM_INPUTCHANNELPOLARITY_RISING);

  sr04->capture_flag = 0;

  HAL_TIM_IC_Start_IT(sr04->echo_htim, sr04->echo_channel);
  HAL_TIM_Base_Start_IT(sr04->echo_htim);
}
*/

/*void delay_ms(uint16_t time_ms) // Cria um delay em ms
{
	__HAL_TIM_SET_COUNTER(&htim1, 0);
	while(__HAL_TIM_GET_COUNTER(&htim1) < time_ms);
}
*/
void sensor_trigger(sensor_t *sr04)
{
	HAL_GPIO_WritePin(sr04->trig_port, sr04->trig_pin, GPIO_PIN_SET);  // pull the TRIG pin HIGH
	delay_ms(10);  // wait for 10 us
	HAL_GPIO_WritePin(sr04->trig_port, sr04->trig_pin, GPIO_PIN_RESET);  // pull the TRIG pin low

	__HAL_TIM_ENABLE_IT(sr04->echo_htim, TIM_IT_CC1);
}
/*
void sensor_distance(sensor_t *sr04)
{
	uint32_t IC_Val1 = 0;
	uint32_t IC_Val2 = 0;
	uint32_t Difference = 0;
	uint8_t Is_First_Captured = 0;  // is the first value captured ?
	uint8_t Distance  = 0;


  }
}
*/
