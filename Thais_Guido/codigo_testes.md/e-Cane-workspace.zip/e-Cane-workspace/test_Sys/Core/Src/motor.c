/*
 * motor.c
 *
 *  Created on: Aug 13, 2024
 *      Author: guidomomm
 */

#include "motor.h"

void motor_config(motor_t motor, TIM_HandleTypeDef *motor_htim, uint16_t motor_channel, sr04_t *sr04){
	
	motor.motor_channel = motor_channel;
	motor.motor_htim = motor_htim;
	motor.sr04 = sr04;
};

void motor_init(motor_t *motor){
	
	HAL_TIM_PWM_Start(motor->motor_htim, motor->motor_channel);
};

void motor_speed(motor_t *motor, uint16_t speed){
	
	if(speed < 0 || speed >100){
		return HAL_ERROR;
	}

	motor->motor_htim->Instance->CCR1 = speed;
};

void motor_pulse(motor_t *motor)
{
	uint32_t dist = 0;

	dist = sensor_distance(motor->sr04);

	if(dist>1500)
	{
		motor_speed(&motor, 0);
		HAL_Delay(50);
	}
	else if(dist<=1500 && motor->sr04->distance>1000)
	{
		motor_speed(&motor, 10);
		HAL_Delay(50);
	}
	else if(dist<=100 && dist>75)
	{
		motor_speed(&motor, 20);
		HAL_Delay(50);
	}
	else if(dist<=75 && dist>50)
	{
		motor_speed(&motor, 30);
		HAL_Delay(50);
	}
	else if(dist<=50 && dist>25)
	{
		motor_speed(&motor, 40);
		HAL_Delay(50);
	}
	else if(dist<=25 && dist>10)
	{
		motor_speed(&motor, 50);
		HAL_Delay(50);
	}
	else if(dist<=10 && dist>=0)
	{
		motor_speed(&motor, 60);
		HAL_Delay(50);
	}
};

/*void motor_blink(motor_t *motor, uint16_t blink){

	sensor_distance(motor.sensor);



};*/
