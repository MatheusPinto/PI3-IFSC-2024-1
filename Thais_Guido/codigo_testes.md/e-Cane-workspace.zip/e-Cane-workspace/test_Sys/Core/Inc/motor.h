/*
 * motor.h
 *
 *  Created on: Aug 13, 2024
 *      Author: guidomomm
 */
#ifndef INC_MOTOR_H_
#define INC_MOTOR_H_

#include "sensor.h"

typedef struct{
	TIM_HandleTypeDef *motor_htim;	//	PWM Timer
	uint16_t motor_channel;	//	PWM Output
	sr04_t *sr04;	//	Linked sensor
}motor_t;

void motor_config(motor_t motor, TIM_HandleTypeDef *motor_htim, uint16_t motor_channel, sr04_t *sr04);
void motor_init(motor_t *motor);
void motor_speed(motor_t *motor, uint16_t speed);
//void motor_pulse(motor_t *motor);

#endif /* INC_MOTOR_H_ */
