/*
 * vibrator.c
 *
 *  Created on: Jul 12, 2024
 *      Author: guidomomm
 */

#include "motor.h"

void motor_config(motor_t motor, TIM_HandleTypeDef *motor_htim, uint16_t motor_channel, sensor_t *sr04)
{
	motor.state = 0;
	motor.motor_channel = motor_channel;
	motor.motor_htim = motor_htim;
	motor.sr04 = sr04;
};

void motor_init(motor_t *motor)
{
	HAL_TIM_PWM_Start(motor->motor_htim, motor->motor_channel);
};

void motor_speed(motor_t motor, uint16_t speed)
{
	if(speed < 0 || speed >100)
	{
		return HAL_ERROR;
	}

	motor.motor_htim->Instance->CCR1 = speed;

	if(motor.motor_htim->Instance->CCR1 == 0)
		motor.state = 0;	// Off
	else
		motor.state = 1;	// On
};

void motor_pulse(motor_t motor)
{
	sensor_distance(motor.sr04);

	if(motor.sr04->distance>150)
	{
		motor_speed(motor, 0);
		HAL_Delay(50);
	}
	else if(motor.sr04->distance<=150 && motor.sr04->distance>100)
	{
		motor_speed(motor, 10);
		HAL_Delay(50);
	}

	else if(motor.sr04->distance<=100 && motor.sr04->distance>75)
	{
		motor_speed(motor, 20);
		HAL_Delay(50);
	}
	else if(motor.sr04->distance<=75 && motor.sr04->distance>50)
	{
		motor_speed(motor, 30);
		HAL_Delay(50);
	}
	else if(motor.sr04->distance<=50 && motor.sr04->distance>25)
	{
		motor_speed(motor, 40);
		HAL_Delay(50);
	}
	else if(motor.sr04->distance<=25 && motor.sr04->distance>10)
	{
		motor_speed(motor, 50);
		HAL_Delay(50);
	}
	else if(motor.sr04->distance<=10 && motor.sr04->distance>1)
	{
		motor_speed(motor, 60);
		HAL_Delay(50);
	}
};

