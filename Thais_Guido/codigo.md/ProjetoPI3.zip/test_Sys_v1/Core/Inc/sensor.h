/*
 * sensor.h
 *
 *  Created on: Jul 11, 2024
 *      Author: guidomomm
 */

#include "stm32f1xx_hal.h"

#ifndef INC_SENSOR_H_
#define INC_SENSOR_H_

typedef struct {
    GPIO_TypeDef *trig_port;  // Trigger pin port
    uint16_t trig_pin;  // Trigger pin number
    TIM_HandleTypeDef *echo_htim;  // Echo pin timer
    uint16_t echo_channel;  // Echo pin timer channel
    uint8_t capture_flag;  // Echo pin capture flag
    uint32_t distance;  // Distance in cm
    uint16_t tim_update_count;  // Timer update count
} sensor_t;

void sensor_config(sensor_t sr04, uint16_t trig_pin, GPIO_TypeDef *trig_port, uint16_t echo_channel, TIM_HandleTypeDef *echo_htim);
void sensor_init(sensor_t *sr04);
void sensor_trigger(sensor_t *sr04);
void sensor_distance(sensor_t *sr04);

#endif /* INC_SENSOR_H_ */
